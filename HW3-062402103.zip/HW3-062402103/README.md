# HW3-062402103 —— 第三次挑战：比较并改进 RayServe 路由

本交付包对应《第三次挑战：比较并改进 RayServe 路由》。实验在**同一台 4 卡服务器**上搭建
「1 个 Ray head 节点 + 4 个逻辑 worker 节点 + 4 个 SGLang 后端 + 4 个 Ray Serve Replica」，
用课程发布的固定负载回放 A / B（两个候选）/ C / D 四组路由策略，并比较缓存收益与热点偏斜。


---

## 1. GPU 与软件版本

### 硬件

| 项目 | 值 |
| --- | --- |
| GPU | 1 × NVIDIA GeForce RTX 4080 + 3 × NVIDIA GeForce RTX 4080 SUPER |
| 显存 | 32760 MiB / 卡 |
| 驱动 | 595.91.07（CUDA 13.2 runtime） |
| CPU / 内存 | 128 vCPU / 503 GB |

四张卡各由一个独立的 SGLang 进程独占（`CUDA_VISIBLE_DEVICES=0..3`），模型为
`Qwen/Qwen3-0.6B`（fp16，约 1.5 GB），单卡显存占用约 19 GB。

### 软件

| 组件 | 版本 |
| --- | --- |
| 操作系统 | Linux（AutoDL 容器） |
| Python | 3.12.3（`/root/miniconda3`） |
| PyTorch | 2.13.0+cu130 |
| SGLang | 0.5.21（`sglang[all]`） |
| Ray | 2.59.0（`ray[serve]`） |
| Transformers | 5.12.1 |
| FastAPI / Starlette | 0.142.2 / 1.7.0 |
| aiohttp | 3.14.4 |

> 负载回放脚本 `run_workload.py` 只需要 `aiohttp`（课程 `requirements.txt`）。

---


## 2. 目录结构

    HW3-姓名/
    ├── README.md
    ├── report.pdf
    ├── AI使用说明情况（第三次挑战）.pdf
    ├── src/
    │   └── target3/
    │       ├── ray_cluster.py          1 head + 4 worker 逻辑集群
    │       ├── start_sglang.sh         启动 4 个 SGLang 后端
    │       ├── stop_sglang.sh
    │       ├── serve_app.py            Ray Serve 四副本应用 + 五套路由配置
    │       ├── adaptive_router.py      D 组自定义路由器
    │       ├── run_experiments.py      单组实验驱动（部署→清缓存→回放→校验）
    │       ├── run_all.sh              单组驱动入口（ulimit / PYTHONPATH）
    │       ├── run_sweep.sh            逐组串行跑完 A–D（每组独立进程）
    │       ├── smoke_test.py           端到端连通性自检
    │       ├── verify_cluster.py       集群存活与 node→backend 映射检查
    │       ├── analyze_results.py      生成报告主表
    │       ├── reset_env.sh            清理上一轮进程与 Ray 会话
    │       └── requirements.txt
    └── results/
        └── target3/
            ├── A_default/run-1, run-2
            ├── B_candidates/candidate-1/run-1, run-2
            ├── B_candidates/candidate-2/run-1, run-2
            ├── C_affinity/run-1, run-2
            ├── D_improved/run-1, run-2
            ├── comparison.json         compare_runs.py 的汇总
            └── comparison_table.md     报告主表

本次挑战文档只描述 target3，交付内容也只有 `src/target3/` 与 `results/target3/`。

---

## 3. 启动与回放

所有命令假定代码在 `/root/hw3/src/target3`，负载在
`/root/hw3/workloads/target3-routing-policies`。

    # (0) 清场：杀掉上一轮驱动进程并复位 Ray 会话
    bash /root/hw3/src/target3/reset_env.sh

    # (1) 启动 4 个 SGLang 后端（每卡一个，端口 30001-30004）
    bash /root/hw3/src/target3/start_sglang.sh \
         /root/autodl-tmp/models/models/Qwen--Qwen3-0.6B/snapshots/master 30001 /root/hw3/logs

    # (2) 自检：4 副本 / 4 节点 / 4 后端 + 三个响应头 + SSE 流
    cd /root/hw3/src/target3
    PYTHONPATH=. python smoke_test.py --policy A_default

    # (3) 集群检查（可选）
    PYTHONPATH=. python verify_cluster.py

    # (4) 跑完 A、B1、B2、C、D（每组一个独立进程，各 2 轮）
    POLICIES=A_default,B_candidate_1,B_candidate_2,C_affinity,D_improved \
    REPEATS=2 HW3_B_SELECTED=64 bash /root/hw3/src/target3/run_sweep.sh

    # (5) 单轮回放命令（等价于 run_experiments.py 内部执行的那一条）
    cd /root/hw3/workloads/target3-routing-policies
    python run_workload.py \
      --policy serve \
      --run-name A_default_1 \
      --router-name p2c \
      --max-ongoing-requests 5 \
      --base-url http://127.0.0.1:8000 \
      --workload mooncake_prefix_workload_v2_seed2026.jsonl \
      --max-in-flight 2048 \
      --output-dir /root/hw3/results/target3/A_default/run-1

---

## 4. 脚本用途

| 脚本 | 用途 |
| --- | --- |
| `ray_cluster.py` | 用 `ray.cluster_utils.Cluster` 起 1 head + 4 worker。每个 worker 带 `serve_slot=1` 与唯一的 `sglang_backend_i=1` 资源：副本申请 `serve_slot=1`，因此每个 worker 最多落一个副本；副本在构造函数里用自己的 Ray node id 查 `cluster_info.json`，从而固定绑定到 SGLang i |
| `start_sglang.sh` | 四个 `sglang.launch_server`，`CUDA_VISIBLE_DEVICES=i`，端口 30001+i，开 `--enable-cache-report`，RadixAttention 前缀缓存默认开启 |
| `serve_app.py` | Ray Serve 应用：`POST /generate` 透传 SGLang 原生请求体与 SSE 流，注入 `X-Ray-Replica-ID` / `X-Ray-Node-ID` / `X-SGLang-Backend`；内含 A/B1/B2/C/D 五套 `max_ongoing_requests` 与 `RequestRouterConfig` |
| `adaptive_router.py` | D 组 `AdaptivePrefixAffinityRouter`：以当前请求的前缀族 id（`X-Session-Id` → `RequestMetadata.session_id`）作为亲和信号，加上路由时刻的副本队列长度，做「亲和优先、过载回退」 |
| `run_experiments.py` | 单组驱动：起集群 → 部署该组路由 → 等 4 副本就绪 → 逐个 `POST /flush_cache` → 调 `run_workload.py` → 校验 `summary.json` 并把结果写进 `manifest.json` |
| `run_all.sh` | 单组入口，设置 `ulimit -n`、`PYTHONPATH`、`RAY_SERVE_SESSION_ID_HEADER_KEY` |
| `run_sweep.sh` | 逐组串行执行，**每组一个独立进程**（规避 Ray Serve 连续 `shutdown()`+`run()` 时偶发的 proxy 起不来问题） |
| `smoke_test.py` | 端到端自检：确认 4 副本、4 节点、4 后端都出现，三个响应头齐全，SSE 输出 token 数正确，且同一前缀第二次命中缓存 |
| `verify_cluster.py` | 打印 5 个节点的存活状态、资源与 node→backend 映射 |
| `analyze_results.py` | 汇总所有 `run-*/summary.json`，输出报告主表（成功率、吞吐、缓存命中率、实际 Prefill token、TTFT p95、端到端 p95、四后端分布） |
| `reset_env.sh` | 清理上一轮驱动进程、`ray stop --force` 并删除 `/tmp/ray` |

---

## 5. 结果目录与报告表格的对应关系

| 报告中的行 | 结果目录 | 路由配置 |
| --- | --- | --- |
| A（基线） | `results/target3/A_default/run-{1,2}` | Ray Serve 默认 `PowerOfTwoChoices`，`max_ongoing_requests=5` |
| B1 | `results/target3/B_candidates/candidate-1/run-{1,2}` | 默认 p2c，`max_ongoing_requests=16` |
| B2 | `results/target3/B_candidates/candidate-2/run-{1,2}` | 默认 p2c，`max_ongoing_requests=64` |
| C | `results/target3/C_affinity/run-{1,2}` | `ConsistentHashRouter(num_fallback_replicas=0)`，按 `X-Session-Id` 哈希 |
| D | `results/target3/D_improved/run-{1,2}` | 自定义 `AdaptivePrefixAffinityRouter` |

每个 `run-*` 目录里是流量发生器生成的**完整**产物：

| 文件 | 内容 |
| --- | --- |
| `config.json` | 命令、模型、路由器、并发参数、负载 SHA-256、校验状态与自定义 metadata |
| `warmups.csv` | 64 条预热请求的逐请求结果 |
| `requests.csv` | 2048 条测量请求的逐请求结果（含 `ttft_s`、`tpot_s`、`latency_s`、`dispatch_lag_s`、`client_queue_s`、`cached_tokens`、`replica_id`、`ray_node_id`、`backend`） |
| `summary.json` | 全程、三个阶段与四个热度层级的汇总指标 |
| `generator.stdout.txt` / `generator.stderr.txt` | 发生器自身的标准输出/错误，便于核对 |

报告主表中的每一个数字都能在对应 `summary.json` 中找到；分阶段结论对应
`summary.json` 的 `traffic_phases.{steady,burst,recovery}`，热点结论对应
`backend_distribution` 与 `backend_token_distribution`。

---

## 6. 复现要点

- 四组实验**共用同一个** Ray Serve HTTP 入口（`http://127.0.0.1:8000`）、同一模型、同一
  SGLang 参数、同一副本拓扑与同一份负载文件；每轮开始前先停止上一轮应用、重新部署，
  再 `POST /flush_cache` 清空四个后端的 RadixAttention 缓存。
- 负载文件不得修改：`run_workload.py` 会校验其 SHA-256
  （`f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03`）。
- 路由头 `X-Session-Id` 与 `X-Prefix-Family` 都等于当前请求的前缀族 id；路由器只读取当前
  请求与当前服务状态，不读取未来请求。
- 每个 `run-*` 的 `requests.csv` 都有 2048 行且 `summary.json` 满足
  `successful=2048 / failed=0 / incomplete=0 / warmup_successful=64 / validation_errors=[]`。
- 若在同一路径重跑，`run_workload.py` 会拒绝覆盖，需加 `--overwrite`
  （`run_experiments.py` 已自动加上）。
