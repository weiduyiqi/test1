| Group | Router | MOR | Success | Throughput (req/s) | Cache hit | Prefill tokens | TTFT p95 (ms) | Latency p95 (ms) | Backend distribution |
|---|---|---|---|---|---|---|---|---|---|
| A | p2c | 5 | 100.0% | 34.32 | 87.61% | 400,446 | 28932.4 | 29454.8 | sglang-0:514 / sglang-1:488 / sglang-2:523 / sglang-3:523 |
| B1 | p2c | 16 | 100.0% | 56.96 | 87.75% | 396,094 | 7874.5 | 8691.2 | sglang-0:503 / sglang-1:522 / sglang-2:502 / sglang-3:521 |
| B2 | p2c | 64 | 100.0% | 54.49 | 87.33% | 409,791 | 9198.6 | 12764.1 | sglang-0:476 / sglang-1:509 / sglang-2:531 / sglang-3:532 |
| C | consistent_hash | 16 | 100.0% | 32.54 | 95.77% | 136,892 | 34703.8 | 35446.2 | sglang-0:156 / sglang-1:263 / sglang-2:460 / sglang-3:1169 |
| D | adaptive_prefix_affinity | 16 | 100.0% | 56.16 | 88.00% | 387,839 | 7831.1 | 8709.3 | sglang-0:524 / sglang-1:511 / sglang-2:497 / sglang-3:516 |
