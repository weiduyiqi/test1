#!/usr/bin/env python3
"""Create the logical Ray cluster used by the routing experiments.

Topology required by the assignment:

    1 head node  +  4 worker nodes   (all on one physical machine)
    Client -> Ray Serve HTTP Proxy -> Replica 0..3 -> SGLang 0..3

ray.cluster_utils.Cluster starts every node as a real, separate Ray node
process (its own node id, its own raylet) on the local host, so no containers
and no sudo are needed.

Note: the raylet needs a generous file-descriptor limit.  Run the driver from
a shell that has already executed "ulimit -n 65535" (run_all.sh does this),
otherwise the raylet fails to register with the GCS within 30 s and Cluster()
raises "The current node timed out during startup".

Placement guarantee ("one replica per worker node")
---------------------------------------------------
Every worker node is started with two custom resources:

    serve_slot       = 1        (identical on all four workers)
    sglang_backend_i = 1        (unique per worker, i = 0..3)

The Serve deployment requests {"serve_slot": 1} for each of its four replicas.
Because each worker owns exactly 1.0 of that resource and the head node owns
none, Ray can place at most one replica per worker node, so the four replicas
necessarily occupy four *different* nodes.  The unique sglang_backend_i
resource then tells us, deterministically, which SGLang backend lives on which
node -- that mapping is written to cluster_info.json and read by every replica
in its constructor, which is what pins Replica i to SGLang i.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from typing import Dict, Optional

import ray
from ray.cluster_utils import Cluster

SERVE_SLOT_RESOURCE = "serve_slot"
BACKEND_RESOURCE_FMT = "sglang_backend_{}"

DEFAULT_NUM_WORKERS = 4
DEFAULT_BASE_PORT = 30001
DEFAULT_INFO_PATH = "/root/hw3/run/cluster_info.json"


def backend_url(index: int, base_port: int = DEFAULT_BASE_PORT) -> str:
    """HTTP base URL of SGLang backend number index."""
    return "http://127.0.0.1:{}".format(base_port + index)


class RayCluster:
    """Owns the logical Ray cluster for the lifetime of the experiment."""

    def __init__(
        self,
        num_workers: int = DEFAULT_NUM_WORKERS,
        base_port: int = DEFAULT_BASE_PORT,
        info_path: str = DEFAULT_INFO_PATH,
        head_cpus: int = 4,
        worker_cpus: int = 2,
        clean: bool = True,
        verbose: bool = True,
    ) -> None:
        self.clean = clean
        self.num_workers = num_workers
        self.base_port = base_port
        self.info_path = info_path
        # NOTE: these must stay integral.  Ray passes them to the raylet as
        # "--num-cpus=<value>"; a float such as 4.0 makes the raylet die during
        # startup, which surfaces 30 s later as
        # "The current node timed out during startup".
        self.head_cpus = int(head_cpus)
        self.worker_cpus = int(worker_cpus)
        self.verbose = verbose
        self.cluster: Optional[Cluster] = None
        self.info: Dict = {}

    def _log(self, message: str) -> None:
        if self.verbose:
            print("[cluster] {}".format(message), flush=True)

    def _preflight_cleanup(self) -> None:
        """Stop leftover Ray processes and drop the stale session directory.

        A /tmp/ray session left behind by an earlier interrupted run makes the
        new raylet fail to register with the GCS within the 30 s startup
        window, which surfaces as "The current node timed out during startup".
        """
        try:
            subprocess.run(
                ["ray", "stop", "--force"],
                capture_output=True,
                timeout=180,
                check=False,
            )
        except Exception:
            pass
        if os.path.isdir("/tmp/ray"):
            try:
                shutil.rmtree("/tmp/ray")
            except Exception:
                pass

    def start(self) -> "RayCluster":
        if self.clean:
            self._preflight_cleanup()

        # The head node intentionally owns no serve_slot resource, so Serve
        # replicas can never be scheduled onto it.
        self.cluster = Cluster(
            initialize_head=True,
            connect=False,
            head_node_args={
                "num_cpus": self.head_cpus,
                "num_gpus": 0,
                "object_store_memory": 512 * 1024 * 1024,
                # The dashboard costs several seconds of node startup and is
                # not used by the experiments.
                "include_dashboard": False,
            },
            shutdown_at_exit=False,
        )
        self._log("head node started, gcs={}".format(self.cluster.address))

        for i in range(self.num_workers):
            self.cluster.add_node(
                num_cpus=self.worker_cpus,
                num_gpus=0,
                object_store_memory=512 * 1024 * 1024,
                include_dashboard=False,
                resources={
                    SERVE_SLOT_RESOURCE: 1,
                    BACKEND_RESOURCE_FMT.format(i): 1,
                },
            )
            self._log("worker node {} added".format(i))

        ray.init(address=self.cluster.address, ignore_reinit_error=True)

        deadline = time.time() + 120
        while time.time() < deadline:
            alive = [n for n in ray.nodes() if n.get("Alive")]
            if len(alive) >= self.num_workers + 1:
                break
            time.sleep(1.0)
        alive = [n for n in ray.nodes() if n.get("Alive")]

        node_to_backend: Dict[str, int] = {}
        for node in alive:
            resources = node.get("Resources", {}) or {}
            for i in range(self.num_workers):
                if resources.get(BACKEND_RESOURCE_FMT.format(i), 0) > 0:
                    node_to_backend[node["NodeID"]] = i

        head_node_id = None
        if self.cluster.head_node is not None:
            head_node_id = self.cluster.head_node.node_id

        self.info = {
            "gcs_address": self.cluster.address,
            "num_nodes_alive": len(alive),
            "head_node_id": head_node_id,
            "worker_node_ids": sorted(node_to_backend.keys()),
            "node_to_backend": node_to_backend,
            "backend_urls": [
                backend_url(i, self.base_port) for i in range(self.num_workers)
            ],
            "base_port": self.base_port,
            "serve_slot_resource": SERVE_SLOT_RESOURCE,
        }
        self._dump_info()

        self._log(
            "{} nodes alive (1 head + {} workers), node->backend={}".format(
                len(alive), self.num_workers, node_to_backend
            )
        )
        if len(alive) != self.num_workers + 1:
            raise RuntimeError(
                "expected {} alive nodes, saw {}".format(
                    self.num_workers + 1, len(alive)
                )
            )
        if len(node_to_backend) != self.num_workers:
            raise RuntimeError(
                "could not map every worker node to a SGLang backend: {}".format(
                    node_to_backend
                )
            )
        return self

    def _dump_info(self) -> None:
        directory = os.path.dirname(self.info_path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        with open(self.info_path, "w", encoding="utf-8") as handle:
            json.dump(self.info, handle, indent=2)
        self._log("cluster info written to {}".format(self.info_path))

    def shutdown(self) -> None:
        try:
            ray.shutdown()
        except Exception:
            pass
        if self.cluster is not None:
            try:
                self.cluster.shutdown()
            except Exception:
                pass
        self._log("cluster shut down")

    def __enter__(self) -> "RayCluster":
        return self

    def __exit__(self, *exc) -> None:
        self.shutdown()


def start_cluster(**kwargs) -> RayCluster:
    return RayCluster(**kwargs).start()


def load_info(path: str = DEFAULT_INFO_PATH) -> Dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


if __name__ == "__main__":
    cluster = start_cluster()
    print(json.dumps(cluster.info, indent=2))
