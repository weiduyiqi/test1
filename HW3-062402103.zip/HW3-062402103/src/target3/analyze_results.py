#!/usr/bin/env python3
"""Build the paper's main comparison table from the per-run summary.json files.

Usage:
    python analyze_results.py --results-dir results/target3 --output results/target3/comparison_table

Reads every summary.json below the results directory, groups the runs by policy
(using the directory layout produced by run_experiments.py), and emits a
markdown table plus a machine readable json file with the same numbers.
"""

from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

POLICY_ORDER = [
    ("A_default", "A"),
    ("B_candidates/candidate-1", "B1"),
    ("B_candidates/candidate-2", "B2"),
    ("C_affinity", "C"),
    ("D_improved", "D"),
]


def load_runs(results_dir: Path):
    grouped = {}
    for subdir, label in POLICY_ORDER:
        directory = results_dir / subdir
        if not directory.exists():
            continue
        for summary_path in sorted(directory.glob("run-*/summary.json")):
            with summary_path.open(encoding="utf-8") as handle:
                grouped.setdefault(label, []).append(
                    (summary_path, json.load(handle))
                )
    return grouped


def mean(values):
    return statistics.fmean(values) if values else float("nan")


def metric_block(runs):
    success_rate = [r["successful"] / r["requests"] for _, r in runs]
    throughput = [r["throughput_rps"] for _, r in runs]
    cache_hit = [r["cache_hit_rate"] for _, r in runs]
    prefill = [r["computed_prefill_tokens_total"] for _, r in runs]
    ttft_p95 = [r["ttft_s"]["p95"] for _, r in runs]
    ttft_p50 = [r["ttft_s"]["p50"] for _, r in runs]
    latency_p95 = [r["latency_s"]["p95"] for _, r in runs]
    latency_p50 = [r["latency_s"]["p50"] for _, r in runs]
    tpot_p95 = [r["tpot_s"]["p95"] for _, r in runs]
    client_queue_p95 = [r["client_queue_s"]["p95"] for _, r in runs]
    dispatch_lag_p95 = [r["dispatch_lag_s"]["p95"] for _, r in runs]
    backends = []
    for _, r in runs:
        backends.append(r["backend_distribution"])
    return {
        "repeats": len(runs),
        "success_rate": mean(success_rate),
        "throughput_rps": mean(throughput),
        "cache_hit_rate": mean(cache_hit),
        "computed_prefill_tokens_total": mean(prefill),
        "ttft_p50_s": mean(ttft_p50),
        "ttft_p95_s": mean(ttft_p95),
        "latency_p50_s": mean(latency_p50),
        "latency_p95_s": mean(latency_p95),
        "tpot_p95_s": mean(tpot_p95),
        "client_queue_p95_s": mean(client_queue_p95),
        "dispatch_lag_p95_s": mean(dispatch_lag_p95),
        "backend_distribution": backends,
        "router_name": runs[0][1]["router_name"],
        "max_ongoing_requests": runs[0][1]["max_ongoing_requests"],
    }


def format_backend(distribution):
    if not distribution:
        return "-"
    keys = sorted(distribution, key=lambda k: str(k))
    return " / ".join("{}:{}".format(k, distribution[k]) for k in keys)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", default="results/target3")
    parser.add_argument("--output", default="results/target3/comparison_table")
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    grouped = load_runs(results_dir)
    if not grouped:
        raise SystemExit("no run-*/summary.json found below {}".format(results_dir))

    table = {label: metric_block(runs) for label, runs in grouped.items()}

    header = (
        "| Group | Router | MOR | Success | Throughput (req/s) | Cache hit | "
        "Prefill tokens | TTFT p95 (ms) | Latency p95 (ms) | Backend distribution |"
    )
    separator = "|" + "---|" * 10
    lines = [header, separator]
    for label in [lab for _, lab in POLICY_ORDER if lab in table]:
        m = table[label]
        lines.append(
            "| {} | {} | {} | {:.1%} | {:.2f} | {:.2%} | {:,.0f} | {:.1f} | {:.1f} | {} |".format(
                label,
                m["router_name"],
                m["max_ongoing_requests"],
                m["success_rate"],
                m["throughput_rps"],
                m["cache_hit_rate"],
                m["computed_prefill_tokens_total"],
                m["ttft_p95_s"] * 1000.0,
                m["latency_p95_s"] * 1000.0,
                format_backend(m["backend_distribution"][0]),
            )
        )
    markdown = "\n".join(lines) + "\n"

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix(".md").write_text(markdown, encoding="utf-8")
    output.with_suffix(".json").write_text(
        json.dumps(table, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(markdown)
    print("written:", output.with_suffix(".md"), "and", output.with_suffix(".json"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
