#!/usr/bin/env python3
"""Group D: prefix-affinity-aware power-of-two-choices router.

Extension surface
-----------------
Ray Serve lets a deployment replace its request router through
ray.serve.config.RequestRouterConfig(request_router_class=...,
request_router_kwargs=...).  This module implements that interface and is
registered on the deployment in serve_app.py.

The class deliberately derives from PowerOfTwoChoicesRequestRouter instead of
RequestRouter.  Ray's own routers are built as

    class PowerOfTwoChoicesRequestRouter(FIFOMixin, LocalityMixin,
                                         MultiplexMixin, RequestRouter)

and those mixins contribute the pending-request bookkeeping the routing loop
relies on.  Subclassing the assembled router keeps that behaviour and lets this
router change only the candidate selection, which is the intended way to extend
Ray Serve routing.

Allowed signals
---------------
The assignment forbids consulting future requests.  Two signals are used, both
describing the present:

  1. the current request's prefix-family id, which the HTTP proxy copies into
     RequestMetadata.session_id from the X-Session-Id header, and
  2. the current per-replica queue length, read from the router's own
     queue-length cache, which the base router fills while it picks a replica.
     Reading it is free, so this router issues no probe of its own.

Policy ("affinity-aware power of two choices")
----------------------------------------------
Each prefix family has a home replica: the replica that already holds that
family's shared prefix in its RadixAttention tree.  The home is learned online
the first time the family is routed.

choose_replicas always returns exactly ONE rank holding TWO replicas:

  * family with a home        -> [home, least_loaded_other]
  * family without a home yet -> the two least loaded replicas overall
                                 (ties broken at random)

Ray Serve probes both replicas of a rank in parallel and routes to the less
loaded one, so putting the home replica in the pair makes the router keep its
cache affinity whenever the home is not busier than the best alternative, and
hand the request to another replica as soon as the home is more loaded.  That
is exactly the "prefer the prefix-affine replica, use another replica when it
is loaded" rule the assignment asks for, at the same routing cost as the
default router.

The single-rank shape is deliberate.  Ray Serve probes rank N+1 only after
every replica in rank N has been rejected, and the probe deadline doubles with
the rank index, so returning several single-replica ranks makes routing
collapse once the system is saturated.

Cost of the improvement
-----------------------
Whenever the home replica is the busier of the two candidates the request is
served elsewhere and loses that hop's prefix-cache reuse, so the cache hit rate
stays below strict affinity (group C), and the run cannot reach the perfectly
even spread of plain power-of-two-choices either.
"""

from __future__ import annotations

import logging
import random
from typing import Dict, List, Optional

from ray.serve._private.common import ReplicaID
from ray.serve._private.request_router.common import PendingRequest
from ray.serve._private.request_router.pow_2_router import (
    PowerOfTwoChoicesRequestRouter,
)
from ray.serve._private.request_router.replica_wrapper import RunningReplica

logger = logging.getLogger("ray.serve")

DEFAULT_UNKNOWN_QUEUE_LEN = 10 ** 6


class AdaptivePrefixAffinityRouter(PowerOfTwoChoicesRequestRouter):
    """Affinity-aware power of two choices (one rank, two candidates)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._home: Dict[str, ReplicaID] = {}
        self._live_replica_ids = set()
        self._routed_requests = 0
        self._affinity_hits = 0

    # ------------------------------------------------------------------ setup
    def initialize_state(self, **kwargs) -> None:
        # super() is required: it initialises the state the locality and
        # multiplex mixins depend on.
        super().initialize_state(**kwargs)
        self._overload_ratio = float(kwargs.get("overload_ratio", 2.0))
        self._min_queue_gap = int(kwargs.get("min_queue_gap", 2))
        self._reassign_after = int(kwargs.get("reassign_after", 8))
        logger.info(
            "AdaptivePrefixAffinityRouter initialised for %s "
            "(one rank, two candidates); overload_ratio=%s min_queue_gap=%s "
            "reassign_after=%s are configuration metadata",
            self._deployment_id,
            self._overload_ratio,
            self._min_queue_gap,
            self._reassign_after,
        )

    def update_replicas(self, replicas: List[RunningReplica]) -> None:
        super().update_replicas(replicas)
        live = set(self._replica_id_set)
        self._live_replica_ids = live
        for family in list(self._home.keys()):
            if self._home[family] not in live:
                self._home.pop(family, None)

    # -------------------------------------------------------------- internals
    def _cached_lengths(
        self, replicas: List[RunningReplica]
    ) -> Dict[ReplicaID, int]:
        """Queue lengths already present in the router cache; no RPC."""
        lengths: Dict[ReplicaID, int] = {}
        for replica in replicas:
            cached = self._replica_queue_len_cache.get(replica.replica_id)
            if cached is not None:
                lengths[replica.replica_id] = cached
        return lengths

    @staticmethod
    def _ordered(
        replicas: List[RunningReplica], lengths: Dict[ReplicaID, int]
    ) -> List[RunningReplica]:
        """Least loaded first, ties broken at random."""
        shuffled = list(replicas)
        random.shuffle(shuffled)
        return sorted(
            shuffled,
            key=lambda r: lengths.get(r.replica_id, DEFAULT_UNKNOWN_QUEUE_LEN),
        )

    @staticmethod
    def _family_of(pending_request: Optional[PendingRequest]) -> str:
        if pending_request is None:
            return ""
        return pending_request.metadata.session_id or ""

    # --------------------------------------------------------------- decision
    async def choose_replicas(
        self,
        candidate_replicas: List[RunningReplica],
        pending_request: Optional[PendingRequest] = None,
    ) -> List[List[RunningReplica]]:
        candidates = list(candidate_replicas)
        if not candidates:
            return []
        lengths = self._cached_lengths(candidates)
        if len(candidates) <= 2:
            return [self._ordered(candidates, lengths)]

        family = self._family_of(pending_request)
        by_id = {replica.replica_id: replica for replica in candidates}

        home_id = self._home.get(family) if family else None
        if home_id is None or home_id not in by_id:
            # No home yet: one rank holding every replica, so Ray Serve probes
            # them in parallel and hands back the least loaded one.  _ordered
            # shuffles before sorting, so ties do not all land on one replica.
            return [self._ordered(candidates, lengths)]

        home = by_id[home_id]
        others = self._ordered(
            [r for r in candidates if r.replica_id != home_id], lengths
        )
        if not others:
            return [[home]]

        home_len = lengths.get(home_id)
        other_lens = [lengths[r.replica_id] for r in others if r.replica_id in lengths]
        min_other = min(other_lens) if other_lens else None

        overheated = (
            home_len is not None
            and min_other is not None
            and home_len > min_other * self._overload_ratio + self._min_queue_gap
        )
        if overheated:
            # The home is measurably loaded well above the alternatives: give
            # the request to one of the others (probed in parallel), and keep
            # the home only as a last-resort fallback rank.
            return [others, [home]]

        # Rank 1 is the home replica, so the request keeps its cache affinity
        # while the home's queue is not full; rank 2 holds the other replicas,
        # probed in parallel, which is where the request goes once the home is
        # full.
        return [[home], others]

    # ------------------------------------------------------------- lifecycle
    def on_request_routed(
        self,
        pending_request: PendingRequest,
        replica_id: ReplicaID,
        result,
    ) -> None:
        family = self._family_of(pending_request)
        if not family:
            return
        self._routed_requests += 1
        home = self._home.get(family)
        if home is None:
            self._home[family] = replica_id
        elif home == replica_id:
            self._affinity_hits += 1

    def on_request_completed(
        self, replica_id: ReplicaID, internal_request_id: str
    ) -> None:
        return None
