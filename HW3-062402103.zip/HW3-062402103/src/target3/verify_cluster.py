#!/usr/bin/env python3
"""Print a short liveness report for the logical Ray cluster."""
import json
import sys

import ray

from ray_cluster import load_info


def main() -> int:
    info = load_info()
    ray.init(address=info["gcs_address"], ignore_reinit_error=True, logging_level="ERROR")
    nodes = ray.nodes()
    alive = [n for n in nodes if n.get("Alive")]
    print("gcs_address     :", info["gcs_address"])
    print("nodes alive     :", len(alive), "(expected 1 head + 4 workers)")
    print("head node id    :", info.get("head_node_id"))
    print("node -> backend :", json.dumps(info["node_to_backend"]))
    print("backend urls    :", info["backend_urls"])
    for node in alive:
        resources = node.get("Resources", {})
        print(
            "  node {} cpus={} serve_slot={} gpu={}".format(
                node["NodeID"][:16],
                resources.get("CPU"),
                resources.get("serve_slot", 0),
                resources.get("GPU", 0),
            )
        )
    ok = len(alive) == 5
    print("CLUSTER_OK" if ok else "CLUSTER_BAD")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
