#!/bin/bash
# Launch four independent SGLang servers, one per GPU.
#
#   Client -> Ray Serve HTTP Proxy -> Replica 0..3 -> SGLang 0..3
#
# Each SGLang process sees exactly one GPU (CUDA_VISIBLE_DEVICES=i) and serves the
# SGLang native HTTP API on its own port.  RadixAttention (prefix caching) is on by
# default; --enable-cache-report additionally makes the OpenAI-compatible responses
# report cached tokens.  The native /generate stream always carries
# meta_info.cached_tokens, which the workload generator records as "cached_tokens".
#
# Usage:  bash start_sglang.sh <MODEL_PATH> [BASE_PORT] [LOG_DIR]
set -u

MODEL=$1
BASE_PORT=$2
LOG_DIR=$3
PY=/root/miniconda3/bin/python
MEM_FRACTION=0.55

if [ -z "$MODEL" ]; then MODEL=Qwen/Qwen3-0.6B; fi
if [ -z "$BASE_PORT" ]; then BASE_PORT=30001; fi
if [ -z "$LOG_DIR" ]; then LOG_DIR=/root/hw3/logs; fi
if printenv PYTHON_BIN >/dev/null 2>&1; then PY=$(printenv PYTHON_BIN); fi
if printenv SGLANG_MEM_FRACTION >/dev/null 2>&1; then MEM_FRACTION=$(printenv SGLANG_MEM_FRACTION); fi

mkdir -p "$LOG_DIR"

for i in 0 1 2 3; do
  port=$((BASE_PORT + i))
  CUDA_VISIBLE_DEVICES=$i nohup "$PY" -m sglang.launch_server \
      --model-path "$MODEL" \
      --host 127.0.0.1 \
      --port "$port" \
      --tp-size 1 \
      --mem-fraction-static "$MEM_FRACTION" \
      --enable-cache-report \
      --log-level warning \
      > "$LOG_DIR/sglang_$i.log" 2>&1 &
  echo "sglang-$i  gpu=$i  port=$port  pid=$!"
done

echo "waiting for the four backends to become healthy ..."
for i in 0 1 2 3; do
  port=$((BASE_PORT + i))
  ready=0
  for _ in $(seq 1 300); do
    if curl -sf -m 2 "http://127.0.0.1:$port/health" >/dev/null 2>&1; then
      echo "sglang-$i ready on port $port"
      ready=1
      break
    fi
    sleep 2
  done
  if [ "$ready" = "0" ]; then echo "sglang-$i FAILED to become healthy"; fi
done
