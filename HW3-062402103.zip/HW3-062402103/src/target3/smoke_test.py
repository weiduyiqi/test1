#!/usr/bin/env python3
"""End-to-end smoke test: proxy -> replica -> SGLang, headers and streaming.

Deploys one policy, waits until four replicas / four Ray nodes / four SGLang
backends have answered, flushes the caches, and then sends a handful of
streaming /generate requests through the Ray Serve HTTP proxy, checking that

  * the three routing response headers are present and consistent,
  * the SSE stream is forwarded and yields exactly the requested token count,
  * meta_info.cached_tokens behaves as expected on a repeated prefix.
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request

from run_experiments import (
    PROXY_URL,
    RayCluster,
    flush_caches,
    get,
    normalize_headers,
    wait_for_proxy,
    wait_for_replicas,
)
from ray_cluster import DEFAULT_INFO_PATH


def build_tokens(prefix_seed: int, prefix_len: int, suffix_len: int, suffix_seed: int):
    prefix = [(4096 + (i * prefix_seed) % 60000) for i in range(prefix_len)]
    suffix = [(4096 + (i * suffix_seed) % 60000) for i in range(suffix_len)]
    return prefix + suffix


def stream_generate(input_ids, family, request_id, max_new_tokens=8):
    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": 0.0,
            "max_new_tokens": max_new_tokens,
            "min_new_tokens": max_new_tokens,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
        "stream": True,
    }
    request = urllib.request.Request(
        PROXY_URL + "/generate",
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "X-Session-Id": family,
            "X-Workload-Request-ID": request_id,
            "X-Prefix-Family": family,
        },
        method="POST",
    )
    output_ids = []
    cached = None
    with urllib.request.urlopen(request, timeout=300) as response:
        headers = normalize_headers(response.headers)
        for raw in response:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            body = line[5:].strip()
            if not body or body == "[DONE]":
                continue
            chunk = json.loads(body)
            if chunk.get("output_ids"):
                if cached is None:
                    cached = (chunk.get("meta_info") or {}).get("cached_tokens")
                output_ids = chunk["output_ids"]
    return headers, output_ids, cached


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy", default="A_default")
    parser.add_argument("--keep-cluster", action="store_true")
    args = parser.parse_args()

    from serve_app import deploy, policy_table

    spec = policy_table()[args.policy]
    print("policy:", args.policy, "router:", spec["router_name"],
          "max_ongoing_requests:", spec["max_ongoing_requests"], flush=True)

    cluster = RayCluster(info_path=DEFAULT_INFO_PATH)
    cluster.start()
    try:
        deploy(args.policy)
        wait_for_proxy()
        live = wait_for_replicas(4)
        print("live replicas :", len(live["replicas"]))
        print("live nodes    :", len(live["nodes"]))
        print("live backends :", sorted(live["backends"]))
        flush_caches()

        ok = True
        seen = set()
        for i in range(12):
            family = "smoke-family-{}".format(i % 4)
            ids = build_tokens(37, 512, 64, 91)
            headers, out, cached = stream_generate(ids, family, "smoke-{:03d}".format(i), 8)
            for name in ("x-ray-replica-id", "x-ray-node-id", "x-sglang-backend"):
                if not headers.get(name):
                    print("MISSING HEADER", name)
                    ok = False
            seen.add((headers.get("x-ray-replica-id"), headers.get("x-ray-node-id"),
                      headers.get("x-sglang-backend")))
            if len(out) != 8:
                print("BAD OUTPUT LEN", len(out))
                ok = False
            if i < 4:
                print("  req{} replica={} node={} backend={} cached={}".format(
                    i,
                    str(headers.get("x-ray-replica-id"))[:40],
                    str(headers.get("x-ray-node-id"))[:12],
                    headers.get("x-sglang-backend"),
                    cached,
                ))
        print("distinct (replica,node,backend) triples:", len(seen))
        backend_of = {}
        for replica, node, backend in seen:
            backend_of.setdefault(replica, set()).add(backend)
        for replica, backends in backend_of.items():
            if len(backends) != 1:
                print("REPLICA NOT PINNED", replica, backends)
                ok = False
        print("SMOKE_OK" if ok else "SMOKE_BAD")
        return 0 if ok else 1
    finally:
        if not args.keep_cluster:
            cluster.shutdown()


if __name__ == "__main__":
    sys.exit(main())
