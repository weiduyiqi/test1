#!/bin/bash
# Run each routing group in its own driver process.
#
# Ray Serve could not always bring the HTTP proxy back up when a single driver
# process ran serve.shutdown() + serve.run() for several policies in a row, so
# every group gets a fresh driver and a fresh logical Ray cluster.
#
#   POLICIES=A_default,B_candidate_1 REPEATS=2 bash run_sweep.sh
ulimit -n 65535
export PATH=/root/miniconda3/bin:$PATH
export HOME=/root
export PYTHONPATH=/root/hw3/src/target3
export HW3_ROOT=/root/hw3

POLICIES=${POLICIES:-A_default,B_candidate_1,B_candidate_2,C_affinity,D_improved}
REPEATS=${REPEATS:-1}
# Value chosen for group B; reused by C and D.
export HW3_B_SELECTED=${HW3_B_SELECTED:-64}

LOG_DIR=/root/hw3/logs
mkdir -p "$LOG_DIR"
IFS=',' read -ra LIST <<< "$POLICIES"

failed=""
for policy in "${LIST[@]}"; do
  echo "########## $(date +%H:%M:%S) policy $policy (repeats=$REPEATS) ##########"
  if bash /root/hw3/src/target3/run_all.sh --policies "$policy" --repeats "$REPEATS" \
        > "$LOG_DIR/sweep_$policy.log" 2>&1; then
    echo "OK $policy"
  else
    echo "FAILED $policy (see $LOG_DIR/sweep_$policy.log)"
    failed="$failed $policy"
  fi
done

if [ -n "$failed" ]; then
  echo "SWEEP_FAILED:$failed"
  exit 1
fi
echo "SWEEP_OK"
