#!/bin/bash
# Stop every SGLang server previously started by start_sglang.sh.
set -u
pkill -f "sglang.launch_server" && echo "sent SIGTERM to sglang.launch_server" || echo "no sglang server running"
sleep 3
if pgrep -f "sglang.launch_server" >/dev/null; then pkill -9 -f "sglang.launch_server"; echo "force killed"; fi
