#!/usr/bin/env python3
"""Ray Serve application: four replicas, one per worker node, each pinned to
one SGLang backend.

    Client -> Ray Serve HTTP Proxy -> Replica 0..3 -> SGLang 0..3

The deployment exposes POST /generate with the SGLang native request body
({"input_ids": [...], "sampling_params": {...}, "stream": true}), forwards the
three routing headers the workload generator sends, streams the SGLang SSE
response back untouched, and stamps every response with

    X-Ray-Replica-ID     identity of the Serve replica that served the request
    X-Ray-Node-ID        identity of the Ray node that replica runs on
    X-SGLang-Backend     identity of the SGLang backend the replica is pinned to

A replica never picks a backend at request time: it resolves its own Ray node
id in the constructor and looks that node up in cluster_info.json, so the
replica -> backend binding is fixed for the whole run.

Implementation note: this is a plain Serve deployment whose __call__ returns a
Starlette StreamingResponse (the same pattern Ray Serve uses for its own
streaming benchmarks).  The FastAPI @serve.ingress integration of Ray 2.59 is
not used because its make_fastapi_class_based_view() step does not re-bind
"self" with FastAPI 0.142 / Starlette 1.7, which makes every route fail with
422 "query.self Field required".
"""

from __future__ import annotations

import json
import os
import socket
import time
import urllib.error
import urllib.request
from typing import Dict, List, Optional

import aiohttp
import ray
from ray import serve
from ray.serve.config import RequestRouterConfig
from starlette.requests import Request
from starlette.responses import Response, StreamingResponse

CLUSTER_INFO_PATH = os.environ.get(
    "HW3_CLUSTER_INFO", "/root/hw3/run/cluster_info.json"
)
FORWARD_HEADERS = ("X-Session-Id", "X-Workload-Request-ID", "X-Prefix-Family")
DEPLOYMENT_NAME = "sglang_routing_replica"

# Group B evaluates two non-default values of max_ongoing_requests and the
# better one is then reused by C and D.  Override through the environment.
B_CANDIDATE_1 = int(os.environ.get("HW3_B_CANDIDATE_1", "16"))
B_CANDIDATE_2 = int(os.environ.get("HW3_B_CANDIDATE_2", "64"))
B_SELECTED = int(os.environ.get("HW3_B_SELECTED", "16"))

os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")


def _load_cluster_info(path: str = CLUSTER_INFO_PATH) -> Dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


class SGLangRoutingReplica:
    """One Serve replica, pinned to exactly one SGLang backend."""

    def __init__(self) -> None:
        context = serve.get_replica_context()
        self.replica_id: str = str(context.replica_id)
        self.replica_rank: str = str(getattr(context, "rank", ""))
        self.node_id: str = ray.get_runtime_context().get_node_id()

        info = _load_cluster_info()
        mapping: Dict[str, int] = info["node_to_backend"]
        if self.node_id not in mapping:
            raise RuntimeError(
                "replica landed on node {} which is not mapped to any SGLang "
                "backend; node_to_backend={}".format(self.node_id, mapping)
            )
        self.backend_index: int = int(mapping[self.node_id])
        self.backend_url: str = info["backend_urls"][self.backend_index]
        self.backend_name: str = "sglang-{}".format(self.backend_index)
        self._session: Optional[aiohttp.ClientSession] = None
        print(
            "[replica] {} rank={} node={} -> backend={} ({})".format(
                self.replica_id,
                self.replica_rank,
                self.node_id[:16],
                self.backend_name,
                self.backend_url,
            ),
            flush=True,
        )

    # ------------------------------------------------------------- plumbing
    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(
                total=None, connect=30.0, sock_connect=30.0, sock_read=900.0
            )
            connector = aiohttp.TCPConnector(limit=0, ttl_dns_cache=300)
            self._session = aiohttp.ClientSession(
                timeout=timeout, connector=connector
            )
        return self._session

    def _response_headers(self) -> Dict[str, str]:
        return {
            "X-Ray-Replica-ID": self.replica_id,
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend_name,
        }

    # ------------------------------------------------------------- handlers
    async def __call__(self, request: Request) -> Response:
        path = request.url.path
        if path.endswith("/") and len(path) > 1:
            path = path.rstrip("/")
        if path == "/generate":
            return await self._generate(request)
        if path == "/backend":
            return Response(
                content=json.dumps(
                    {
                        "replica_id": self.replica_id,
                        "rank": self.replica_rank,
                        "ray_node_id": self.node_id,
                        "backend": self.backend_name,
                        "backend_url": self.backend_url,
                    }
                ),
                media_type="application/json",
                headers=self._response_headers(),
            )
        return Response(
            content=json.dumps({"error": "not found", "path": path}),
            status_code=404,
            media_type="application/json",
        )

    async def _generate(self, request: Request) -> Response:
        body = await request.body()
        headers = {"Content-Type": "application/json"}
        for name in FORWARD_HEADERS:
            value = request.headers.get(name)
            if value:
                headers[name] = value

        session = await self._get_session()
        upstream = await session.post(
            self.backend_url + "/generate", data=body, headers=headers
        )
        response_headers = self._response_headers()

        if upstream.status != 200:
            payload = await upstream.text()
            upstream.release()
            return Response(
                content=payload,
                status_code=upstream.status,
                headers=response_headers,
                media_type="application/json",
            )

        content_type = upstream.headers.get("Content-Type", "text/event-stream")

        async def stream_body():
            try:
                async for chunk in upstream.content.iter_any():
                    yield chunk
            finally:
                upstream.release()

        return StreamingResponse(
            stream_body(),
            status_code=200,
            headers=response_headers,
            media_type=content_type,
        )


def _p2c_config() -> Optional[RequestRouterConfig]:
    # None keeps Ray Serve's default PowerOfTwoChoicesRequestRouter.
    return None


def _consistent_hash_config() -> RequestRouterConfig:
    return RequestRouterConfig(
        request_router_class=(
            "ray.serve.experimental.consistent_hash_router.ConsistentHashRouter"
        ),
        request_router_kwargs={"num_fallback_replicas": 0},
    )


def _adaptive_config() -> RequestRouterConfig:
    from adaptive_router import AdaptivePrefixAffinityRouter

    return RequestRouterConfig(
        request_router_class=AdaptivePrefixAffinityRouter,
        request_router_kwargs={
            "overload_ratio": 2.0,
            "min_queue_gap": 2,
            "reassign_after": 8,
        },
    )


def policy_table() -> Dict[str, Dict]:
    """The five configurations reported in the paper table."""
    return {
        "A_default": {
            "label": "A",
            "router_name": "p2c",
            "max_ongoing_requests": 5,
            "request_router_config": _p2c_config(),
            "note": "Ray Serve default PowerOfTwoChoices router",
        },
        "B_candidate_1": {
            "label": "B1",
            "router_name": "p2c",
            "max_ongoing_requests": B_CANDIDATE_1,
            "request_router_config": _p2c_config(),
            "note": "p2c with max_ongoing_requests={}".format(B_CANDIDATE_1),
        },
        "B_candidate_2": {
            "label": "B2",
            "router_name": "p2c",
            "max_ongoing_requests": B_CANDIDATE_2,
            "request_router_config": _p2c_config(),
            "note": "p2c with max_ongoing_requests={}".format(B_CANDIDATE_2),
        },
        "C_affinity": {
            "label": "C",
            "router_name": "consistent_hash",
            "max_ongoing_requests": B_SELECTED,
            "request_router_config": _consistent_hash_config(),
            "note": "ConsistentHashRouter(num_fallback_replicas=0) over X-Session-Id",
        },
        "D_improved": {
            "label": "D",
            "router_name": "adaptive_prefix_affinity",
            "max_ongoing_requests": B_SELECTED,
            "request_router_config": _adaptive_config(),
            "note": "custom AdaptivePrefixAffinityRouter",
        },
    }


def build_app(policy: str = "A_default"):
    """Return the bound Serve application for the named policy."""
    table = policy_table()
    if policy not in table:
        raise KeyError(
            "unknown policy {!r}; choose from {}".format(policy, sorted(table))
        )
    spec = table[policy]

    options = dict(
        name=DEPLOYMENT_NAME,
        num_replicas=4,
        max_ongoing_requests=int(spec["max_ongoing_requests"]),
        max_replicas_per_node=1,
        ray_actor_options={
            "num_cpus": 0.1,
            "resources": {"serve_slot": 1},
        },
    )
    if spec["request_router_config"] is not None:
        options["request_router_config"] = spec["request_router_config"]

    deployment = serve.deployment(**options)(SGLangRoutingReplica)
    return deployment.bind()


PROXY_HOST = "127.0.0.1"
PROXY_PORT = int(os.environ.get("HW3_PROXY_PORT", "8000"))


def _proxy_port_open(timeout_s: float = 2.0) -> bool:
    try:
        with socket.create_connection((PROXY_HOST, PROXY_PORT), timeout=timeout_s):
            return True
    except OSError:
        return False


def _proxy_answers(timeout_s: float = 5.0) -> bool:
    """True once the HTTP proxy answers at all (a 503 still counts)."""
    request = urllib.request.Request(
        "http://{}:{}/backend".format(PROXY_HOST, PROXY_PORT), method="GET"
    )
    try:
        urllib.request.urlopen(request, timeout=timeout_s)
        return True
    except urllib.error.HTTPError:
        return True
    except Exception:
        return False


def deploy(
    policy: str = "A_default",
    route_prefix: str = "/",
    name: str = "hw3",
    attempts: int = 3,
    proxy_timeout_s: float = 150.0,
    shutdown_first: bool = True,
):
    """(Re)deploy the named policy, replacing whatever app ran before.

    serve.shutdown() followed by serve.run() occasionally leaves the HTTP proxy
    down (the controller is killed by ray.kill during graceful shutdown and the
    new one never binds the port).  Retry the whole cycle a few times before
    giving up.
    """
    if shutdown_first:
        serve.shutdown()
        deadline = time.time() + 30.0
        while time.time() < deadline and _proxy_port_open():
            time.sleep(0.5)

    last_error: Optional[BaseException] = None
    for attempt in range(1, attempts + 1):
        try:
            handle = serve.run(
                build_app(policy),
                name=name,
                route_prefix=route_prefix,
                blocking=False,
            )
        except Exception as exc:  # pragma: no cover - retry path
            last_error = exc
            print("[deploy] serve.run failed on attempt {}: {!r}".format(attempt, exc),
                  flush=True)
            time.sleep(5.0)
            continue

        deadline = time.time() + proxy_timeout_s
        while time.time() < deadline:
            if _proxy_answers():
                return handle
            time.sleep(1.0)

        last_error = RuntimeError(
            "Ray Serve HTTP proxy did not come up within {}s".format(proxy_timeout_s)
        )
        print("[deploy] attempt {} left the proxy down, retrying".format(attempt),
              flush=True)
        try:
            serve.shutdown()
        except Exception:
            pass
        time.sleep(5.0)

    raise RuntimeError("could not deploy {!r}: {!r}".format(policy, last_error))


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Deploy one routing policy.")
    parser.add_argument("--policy", default="A_default")
    parser.add_argument("--route-prefix", default="/")
    parser.add_argument("--app-name", default="hw3")
    args = parser.parse_args()
    deploy(args.policy, args.route_prefix, args.app_name)
    print("deployed", args.policy, "as app", args.app_name)
