#!/usr/bin/env python3
"""Drive the four routing groups A/B/C/D end to end.

For every round the script performs exactly the sequence the workload README
prescribes:

  1. tear down the previous Ray Serve application and deploy this round's
     router configuration on the four replicas;
  2. POST /flush_cache to all four SGLang backends and require four successes;
  3. run the fixed traffic generator, which first issues the 64 prefix warmup
     requests and then the 2048 measured requests;
  4. check the exit status and summary.json of that round.

The Ray cluster (1 head + 4 workers) stays alive for the whole sweep, so the
replicas are not restarted between groups, which keeps the comparison clean.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in os.environ.get("PYTHONPATH", "").split(os.pathsep):
    os.environ["PYTHONPATH"] = str(SRC_DIR) + os.pathsep + os.environ.get("PYTHONPATH", "")
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

import ray  # noqa: E402
from ray import serve  # noqa: E402

from ray_cluster import RayCluster, load_info  # noqa: E402

PROJECT_ROOT = Path(os.environ.get("HW3_ROOT", "/root/hw3"))
WORKLOAD_DIR = Path(
    os.environ.get(
        "HW3_WORKLOAD_DIR", str(PROJECT_ROOT / "workloads" / "target3-routing-policies")
    )
)
RESULTS_DIR = Path(os.environ.get("HW3_RESULTS_DIR", str(PROJECT_ROOT / "results" / "target3")))
RUN_DIR = Path(os.environ.get("HW3_RUN_DIR", str(PROJECT_ROOT / "run")))
INFO_PATH = RUN_DIR / "cluster_info.json"
WORKLOAD_FILE = WORKLOAD_DIR / "mooncake_prefix_workload_v2_seed2026.jsonl"
WORKLOAD_SCRIPT = WORKLOAD_DIR / "run_workload.py"

PROXY_URL = os.environ.get("HW3_PROXY_URL", "http://127.0.0.1:8000")
BASE_PORT = int(os.environ.get("HW3_BASE_PORT", "30001"))
MAX_IN_FLIGHT = int(os.environ.get("HW3_MAX_IN_FLIGHT", "2048"))

MODEL = os.environ.get("HW3_MODEL", "Qwen/Qwen3-0.6B")

# policy -> (results sub-directory, run-name prefix)
POLICY_LAYOUT = {
    "A_default": ("A_default", "A_default"),
    "B_candidate_1": ("B_candidates/candidate-1", "B_candidate_1"),
    "B_candidate_2": ("B_candidates/candidate-2", "B_candidate_2"),
    "C_affinity": ("C_affinity", "C_affinity"),
    "D_improved": ("D_improved", "D_improved"),
}


def log(message: str) -> None:
    print("[run] {}".format(message), flush=True)


# --------------------------------------------------------------------- HTTP
def post(url: str, timeout: float = 60.0, data: bytes = b"{}") -> tuple:
    request = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.status, response.read()


def normalize_headers(message) -> dict:
    """Lower-case HTTP header names so lookups are case insensitive.

    dict(response.headers) would not work: HTTP header names are case
    insensitive on the wire, and uvicorn sends them lower-cased, while the
    names we look for are written in mixed case.
    """
    return {str(key).lower(): str(value) for key, value in message.items()}


def get(url: str, timeout: float = 30.0) -> tuple:
    request = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.status, normalize_headers(response.headers), response.read()


def flush_caches() -> None:
    ok = 0
    for i in range(4):
        url = "http://127.0.0.1:{}/flush_cache".format(BASE_PORT + i)
        for attempt in range(5):
            try:
                status, _ = post(url, timeout=120.0)
                if status == 200:
                    ok += 1
                    break
            except Exception as exc:  # pragma: no cover - retry path
                if attempt == 4:
                    raise RuntimeError("flush_cache failed on {}: {}".format(url, exc))
                time.sleep(1.0)
    if ok != 4:
        raise RuntimeError("only {}/4 SGLang backends flushed their cache".format(ok))
    log("flushed the RadixAttention cache of all 4 SGLang backends")


def wait_for_proxy(timeout_s: float = 180.0) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            get(PROXY_URL + "/backend", timeout=10.0)
            return
        except Exception:
            time.sleep(1.0)
    raise RuntimeError("Ray Serve HTTP proxy did not come up at {}".format(PROXY_URL))


def wait_for_replicas(expected: int = 4, timeout_s: float = 240.0) -> dict:
    """Poll /backend until every replica and backend has answered once."""
    seen_replicas, seen_backends, seen_nodes = set(), set(), set()
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            _, headers, _ = get(PROXY_URL + "/backend", timeout=15.0)
            seen_replicas.add(headers.get("x-ray-replica-id", ""))
            seen_backends.add(headers.get("x-sglang-backend", ""))
            seen_nodes.add(headers.get("x-ray-node-id", ""))
        except Exception:
            pass
        if (
            len(seen_replicas) >= expected
            and len(seen_backends) >= expected
            and len(seen_nodes) >= expected
        ):
            break
        time.sleep(0.2)
    summary = {
        "replicas": sorted(x for x in seen_replicas if x),
        "backends": sorted(x for x in seen_backends if x),
        "nodes": sorted(x for x in seen_nodes if x),
    }
    if not (
        len(summary["replicas"]) == expected
        and len(summary["backends"]) == expected
        and len(summary["nodes"]) == expected
    ):
        raise RuntimeError(
            "expected {} replicas / backends / nodes before starting, saw {}".format(
                expected, summary
            )
        )
    log(
        "4 replicas live: backends={}".format(summary["backends"])
    )
    return summary


# ------------------------------------------------------------------ workload
def run_one_round(
    policy: str,
    run_name: str,
    output_dir: Path,
    router_name: str,
    max_ongoing_requests: int,
    metadata: dict,
    shutdown_first: bool = True,
) -> dict:
    from serve_app import deploy

    log("deploying policy {} (router={}, max_ongoing_requests={})".format(
        policy, router_name, max_ongoing_requests
    ))
    # On a freshly started cluster there is no previous application to stop;
    # calling serve.shutdown() anyway occasionally poisons the following
    # serve.run() and leaves the HTTP proxy down.
    deploy(policy, shutdown_first=shutdown_first)
    wait_for_proxy()
    live = wait_for_replicas(4)
    flush_caches()

    output_dir.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        str(WORKLOAD_SCRIPT),
        "--policy", "serve",
        "--run-name", run_name,
        "--router-name", router_name,
        "--max-ongoing-requests", str(max_ongoing_requests),
        "--base-url", PROXY_URL,
        "--workload", str(WORKLOAD_FILE),
        "--max-in-flight", str(MAX_IN_FLIGHT),
        "--output-dir", str(output_dir),
        "--model", MODEL,
        "--overwrite",
    ]
    for key, value in metadata.items():
        command += ["--metadata", "{}={}".format(key, value)]

    log("starting traffic generator for {}".format(run_name))
    started = time.time()
    completed = subprocess.run(command, capture_output=True, text=True)
    elapsed = time.time() - started
    (output_dir / "generator.stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (output_dir / "generator.stderr.txt").write_text(completed.stderr, encoding="utf-8")
    log("traffic generator finished rc={} in {:.1f}s".format(completed.returncode, elapsed))

    summary_path = output_dir / "summary.json"
    if completed.returncode != 0 or not summary_path.exists():
        tail = (completed.stderr or completed.stdout or "")[-2000:]
        raise RuntimeError(
            "round {} failed (rc={}); generator tail:\n{}".format(
                run_name, completed.returncode, tail
            )
        )
    with summary_path.open(encoding="utf-8") as handle:
        summary = json.load(handle)
    problems = []
    for key in ("failed", "incomplete", "warmup_failed", "warmup_incomplete"):
        if summary.get(key):
            problems.append("{}={}".format(key, summary[key]))
    if summary.get("validation_errors"):
        problems.append("validation_errors={}".format(summary["validation_errors"]))
    if summary.get("successful") != 2048:
        problems.append("successful={}".format(summary.get("successful")))
    if problems:
        raise RuntimeError("round {} is not valid: {}".format(run_name, problems))

    log(
        "round {} valid: successful={} throughput={:.2f} req/s cache_hit={:.4f} "
        "ttft_p95={:.4f}s".format(
            run_name,
            summary["successful"],
            summary["throughput_rps"],
            summary["cache_hit_rate"],
            summary["ttft_s"]["p95"],
        )
    )
    summary["_live_replicas"] = live
    return summary


# ---------------------------------------------------------------------- main
def main() -> int:
    parser = argparse.ArgumentParser(description="Run the A/B/C/D routing groups.")
    parser.add_argument(
        "--policies",
        default="A_default,B_candidate_1,B_candidate_2,C_affinity,D_improved",
        help="comma separated policy keys",
    )
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--results-dir", default=str(RESULTS_DIR))
    parser.add_argument("--skip-cluster-start", action="store_true")
    parser.add_argument("--metadata", action="append", default=[])
    args = parser.parse_args()

    metadata = {}
    for item in args.metadata:
        key, _, value = item.partition("=")
        metadata[key] = value

    from serve_app import policy_table

    table = policy_table()
    metadata.setdefault("ray_version", ray.__version__)

    results_dir = Path(args.results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)

    cluster = RayCluster(info_path=str(INFO_PATH))
    if args.skip_cluster_start:
        info = load_info(str(INFO_PATH))
        ray.init(address=info["gcs_address"], ignore_reinit_error=True)
        cluster.info = info
        log("connected to existing cluster at {}".format(info["gcs_address"]))
    else:
        cluster.start()

    manifest = {"policies": {}, "metadata": metadata, "cluster": cluster.info}
    for policy in [p.strip() for p in args.policies.split(",") if p.strip()]:
        if policy not in table:
            raise SystemExit("unknown policy {!r}".format(policy))
        spec = table[policy]
        subdir, prefix = POLICY_LAYOUT[policy]
        manifest["policies"][policy] = {
            "router_name": spec["router_name"],
            "max_ongoing_requests": spec["max_ongoing_requests"],
            "note": spec["note"],
            "runs": [],
        }
        for repeat in range(1, args.repeats + 1):
            run_name = "{}_{}".format(prefix, repeat)
            out = results_dir / subdir / "run-{}".format(repeat)
            summary = run_one_round(
                policy,
                run_name,
                out,
                spec["router_name"],
                spec["max_ongoing_requests"],
                metadata,
                shutdown_first=(repeat > 1),
            )
            manifest["policies"][policy]["runs"].append(
                {
                    "run": repeat,
                    "run_name": run_name,
                    "dir": str(out),
                    "successful": summary["successful"],
                    "throughput_rps": summary["throughput_rps"],
                    "cache_hit_rate": summary["cache_hit_rate"],
                    "ttft_p95_s": summary["ttft_s"]["p95"],
                    "latency_p95_s": summary["latency_s"]["p95"],
                    "backend_distribution": summary["backend_distribution"],
                }
            )
            with (results_dir / "manifest.json").open("w", encoding="utf-8") as handle:
                json.dump(manifest, handle, indent=2)

    with (results_dir / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    log("all requested policies finished; manifest at {}".format(results_dir / "manifest.json"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
