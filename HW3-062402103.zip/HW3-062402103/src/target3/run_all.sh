#!/bin/bash
# Top-level driver: run one or more routing groups through the Ray Serve entry.
#
#   bash run_all.sh [extra run_experiments.py arguments]
#
# Assumes the four SGLang backends are already up (see start_sglang.sh).
ulimit -n 65535
export PATH=/root/miniconda3/bin:$PATH
export HOME=/root
export PYTHONPATH=/root/hw3/src/target3
export RAY_SERVE_SESSION_ID_HEADER_KEY=x-session-id
export HW3_ROOT=/root/hw3
cd /root/hw3/src/target3 || exit 1
exec /root/miniconda3/bin/python run_experiments.py \
    --results-dir /root/hw3/results/target3 "$@"
