#!/bin/bash
# Stop a previous experiment driver and reset the local Ray session.
#
# Kept in its own file on purpose: running "pkill -f smoke_test" directly on the
# remote command line would also match the shell that is executing it.
set -u
export PATH=/root/miniconda3/bin:$PATH
export HOME=/root

for pattern in "smoke_test.py" "run_experiments.py"; do
  if pgrep -f "$pattern" >/dev/null 2>&1; then
    pkill -9 -f "$pattern"
    echo "stopped $pattern"
  fi
done

sleep 2
ray stop --force >/dev/null 2>&1 || true
rm -rf /tmp/ray
echo "ray session reset"
