import asyncio
import aiohttp
import json
import time
import random
import argparse
from pathlib import Path

import numpy as np
from transformers import AutoTokenizer

SERVER_URL = "http://127.0.0.1:30000"
MODEL_PATH = "Qwen/Qwen3-0.6B"

TOTAL_REQUESTS = 32
MAX_CONCURRENT = 8
MAX_NEW_TOKENS = 16
TEMPERATURE = 0.0
IGNORE_EOS = True
SEED = 2026

PROMPT_LEN = 512
SHARED_PREFIX_LEN = 384
SUFFIX_LEN = PROMPT_LEN - SHARED_PREFIX_LEN

OUTPUT_DIR = Path("results/target1")


def rand_tokens(n, vocab_size):
    return [random.randint(1000, vocab_size - 1) for _ in range(n)]


def generate_loads(tokenizer):
    random.seed(SEED)
    vocab_size = tokenizer.vocab_size

    shared_prefix = rand_tokens(SHARED_PREFIX_LEN, vocab_size)
    shared_requests = []
    for i in range(TOTAL_REQUESTS):
        suffix = rand_tokens(SUFFIX_LEN, vocab_size)
        shared_requests.append({
            "request_id": f"shared-{i}",
            "input_ids": shared_prefix + suffix,
        })

    dispersed_requests = []
    for i in range(TOTAL_REQUESTS):
        prefix = rand_tokens(SHARED_PREFIX_LEN, vocab_size)
        suffix = rand_tokens(SUFFIX_LEN, vocab_size)
        dispersed_requests.append({
            "request_id": f"dispersed-{i}",
            "input_ids": prefix + suffix,
        })

    return shared_requests, dispersed_requests, shared_prefix


async def flush_cache(session, server_url):
    async with session.post(f"{server_url}/flush_cache") as resp:
        text = await resp.text()
        if resp.status != 200:
            raise RuntimeError(f"flush_cache failed: {resp.status} {text}")
        print(f"flush_cache ok: {text}")


async def send_request(session, server_url, input_ids, request_id, group):
    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": TEMPERATURE,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": IGNORE_EOS,
            "sampling_seed": SEED,
        },
        "stream": True,
    }

    start = time.perf_counter()
    ttft = None
    chunks = []
    meta_info = {}
    success = False
    error = None

    try:
        async with session.post(f"{server_url}/generate", json=payload) as resp:
            if resp.status != 200:
                error = f"HTTP {resp.status}: {await resp.text()}"
                end = time.perf_counter()
                return {
                    "request_id": request_id,
                    "group": group,
                    "success": False,
                    "error": error,
                    "prompt_tokens": len(input_ids),
                    "completion_tokens": 0,
                    "cached_tokens": 0,
                    "actual_prefill_tokens": len(input_ids),
                    "ttft_ms": None,
                    "tpot_ms": None,
                    "e2e_ms": (end - start) * 1000,
                    "start_time": start,
                    "end_time": end,
                }

            async for raw_line in resp.content:
                line = raw_line.decode("utf-8").strip()
                if not line:
                    continue
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    if ttft is None:
                        ttft = time.perf_counter() - start

                    if "meta_info" in data:
                        meta_info.update(data["meta_info"])
                    if "text" in data:
                        chunks.append(data["text"])

            end = time.perf_counter()
            success = True

    except Exception as e:
        end = time.perf_counter()
        error = str(e)

    e2e_ms = (end - start) * 1000
    ttft_ms = ttft * 1000 if ttft is not None else None

    prompt_tokens = meta_info.get("prompt_tokens", len(input_ids))
    completion_tokens = meta_info.get("completion_tokens", len(chunks))
    cached_tokens = meta_info.get("cached_tokens", meta_info.get("cache_hit_tokens", 0))
    actual_prefill = max(prompt_tokens - cached_tokens, 0)

    if ttft_ms is not None and completion_tokens > 1:
        tpot_ms = (e2e_ms - ttft_ms) / (completion_tokens - 1)
    else:
        tpot_ms = 0.0

    return {
        "request_id": request_id,
        "group": group,
        "success": success,
        "error": error,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "cached_tokens": cached_tokens,
        "actual_prefill_tokens": actual_prefill,
        "ttft_ms": ttft_ms,
        "tpot_ms": tpot_ms,
        "e2e_ms": e2e_ms,
        "start_time": start,
        "end_time": end,
    }


async def run_group(session, server_url, requests, group, concurrency):
    sem = asyncio.Semaphore(concurrency)

    async def bounded(req):
        async with sem:
            return await send_request(
                session, server_url, req["input_ids"], req["request_id"], group
            )

    tasks = [bounded(req) for req in requests]
    return await asyncio.gather(*tasks)


def percentile(values, p):
    if not values:
        return None
    return float(np.percentile(values, p))


def save_results(results, group):
    group_dir = OUTPUT_DIR / group
    group_dir.mkdir(parents=True, exist_ok=True)

    with open(group_dir / "per_request.jsonl", "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    successful = [r for r in results if r["success"]]
    total = len(results)
    success_rate = len(successful) / total if total else 0.0

    total_output_tokens = sum(r["completion_tokens"] for r in successful)
    total_prompt_tokens = sum(r["prompt_tokens"] for r in successful)
    total_cached_tokens = sum(r["cached_tokens"] for r in successful)
    total_actual_prefill = sum(r["actual_prefill_tokens"] for r in successful)

    cache_hit_rate = (
        total_cached_tokens / total_prompt_tokens if total_prompt_tokens else 0.0
    )

    if successful:
        start_time = min(r["start_time"] for r in successful)
        end_time = max(r["end_time"] for r in successful)
        wall_time = end_time - start_time
        throughput = total_output_tokens / wall_time if wall_time > 0 else 0.0
    else:
        throughput = 0.0

    ttft = [r["ttft_ms"] for r in successful if r["ttft_ms"] is not None]
    tpot = [r["tpot_ms"] for r in successful if r["tpot_ms"] is not None]
    e2e = [r["e2e_ms"] for r in successful if r["e2e_ms"] is not None]

    summary = {
        "group": group,
        "total_requests": total,
        "successful_requests": len(successful),
        "success_rate": success_rate,
        "throughput_tokens_per_sec": throughput,
        "cache_hit_rate": cache_hit_rate,
        "total_prompt_tokens": total_prompt_tokens,
        "total_cached_tokens": total_cached_tokens,
        "total_actual_prefill_tokens": total_actual_prefill,
        "ttft_p50_ms": percentile(ttft, 50),
        "ttft_p95_ms": percentile(ttft, 95),
        "tpot_p50_ms": percentile(tpot, 50),
        "tpot_p95_ms": percentile(tpot, 95),
        "e2e_p50_ms": percentile(e2e, 50),
        "e2e_p95_ms": percentile(e2e, 95),
    }

    with open(group_dir / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    return summary


async def main():
    global OUTPUT_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--server-url", default=SERVER_URL)
    parser.add_argument("--output-dir", default=str(OUTPUT_DIR))
    args = parser.parse_args()

    OUTPUT_DIR = Path(args.output_dir)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    shared_requests, dispersed_requests, shared_prefix = generate_loads(tokenizer)

    loads_dir = OUTPUT_DIR / "loads"
    loads_dir.mkdir(exist_ok=True)
    with open(loads_dir / "shared_prefix.json", "w", encoding="utf-8") as f:
        json.dump(shared_requests, f)
    with open(loads_dir / "dispersed_prefix.json", "w", encoding="utf-8") as f:
        json.dump(dispersed_requests, f)

    async with aiohttp.ClientSession() as session:
        async with session.get(f"{args.server_url}/health") as resp:
            if resp.status != 200:
                raise RuntimeError("Server not healthy")

        print("Warming up server...")
        warmup_tasks = []
        for i in range(3):
            input_ids = rand_tokens(16, tokenizer.vocab_size)
            warmup_tasks.append(
                send_request(session, args.server_url, input_ids, f"warmup-{i}", "warmup")
            )
        await asyncio.gather(*warmup_tasks)
        print("Server warmup done.")

        print("Running shared_prefix group...")
        await flush_cache(session, args.server_url)

        # 共享前缀预热请求，不计入结果
        warmup_input = shared_prefix + rand_tokens(1, tokenizer.vocab_size)
        await send_request(
            session, args.server_url, warmup_input, "shared-warmup", "shared_warmup"
        )

        shared_results = await run_group(
            session, args.server_url, shared_requests, "shared_prefix", MAX_CONCURRENT
        )
        shared_summary = save_results(shared_results, "shared_prefix")
        print(json.dumps(shared_summary, indent=2, ensure_ascii=False))

        print("Running dispersed_prefix group...")
        await flush_cache(session, args.server_url)
        dispersed_results = await run_group(
            session, args.server_url, dispersed_requests, "dispersed_prefix", MAX_CONCURRENT
        )
        dispersed_summary = save_results(dispersed_results, "dispersed_prefix")
        print(json.dumps(dispersed_summary, indent=2, ensure_ascii=False))

        combined = [shared_summary, dispersed_summary]
        with open(OUTPUT_DIR / "summary_combined.json", "w", encoding="utf-8") as f:
            json.dump(combined, f, indent=2, ensure_ascii=False)

        print("\n| 组别 | 成功率 | 吞吐量 | 缓存命中率 | 实际 Prefill tokens | TTFT p50 | TTFT p95 | TPOT p50 | TPOT p95 | E2E p50 | E2E p95 |")
        print("  |----- |------ |--------|-----------|-------------------- |---------|----------|-----------|---------|---------|-------|")
        for s in combined:
            print(
                f"| {s['group']} | {s['success_rate']:.2%} | "
                f"{s['throughput_tokens_per_sec']:.2f} | "
                f"{s['cache_hit_rate']:.2%} | "
                f"{s['total_actual_prefill_tokens']} | "
                f"{s['ttft_p50_ms']:.2f} | {s['ttft_p95_ms']:.2f} | "
                f"{s['tpot_p50_ms']:.2f} | {s['tpot_p95_ms']:.2f} | "
                f"{s['e2e_p50_ms']:.2f} | {s['e2e_p95_ms']:.2f} |"
            )


if __name__ == "__main__":
    asyncio.run(main())