# HW2-chen：SGLang 前缀缓存测量与请求流程阅读

## 1. 项目简介

本项目为第二次挑战作业，包含两个任务：

- 任务一：测量 SGLang 前缀缓存效果，对比 `shared_prefix` 与 `dispersed_prefix` 两组负载。
- 任务二：阅读 SGLang v0.5.14 源码，追踪一条 `/generate` 请求的主要处理流程。

---

## 2. 实验环境与版本

### 2.1 硬件与系统

- GPU：NVIDIA GeForce RTX 4070（8 GB 显存）
- GPU 驱动：615.78.02
- CUDA UMD 版本：13.4
- 操作系统：Windows 11 + WSL2 Ubuntu
- CPU：待填
- 内存：待填
- Python：3.12
- conda 环境：`sglang_env`

### 2.2 软件版本

- SGLang：0.5.14
- Ray：2.56.0
- Transformers：5.8.1
- PyTorch：2.11.0
- 模型：Qwen/Qwen3-0.6B

---

## 3. 安装方法

本项目在已有的 `sglang_env` conda 环境中运行。如需重建环境，可执行：

```bash
conda create -n sglang_env python=3.12 -y
conda activate sglang_env
pip install sglang==0.5.14 ray==2.56.0
```

## 4. 启动与回放命令

### 4.1 启动命令
在一个 WSL Ubuntu 终端中执行：
```bash
conda activate sglang_env
python -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B \
  --host 0.0.0.0 \
  --port 30000 \
  --tp 1
```

---

### 4.2回放命令
另开一个 WSL Ubuntu 终端，激活同一 conda 环境，然后执行：
```bash
cd ~/HW2-chen
conda activate sglang_env
python src/run_experiment.py --server-url http://127.0.0.1:30000
```

---

## 5. 脚本作用
 - src/run_experiment.py
构造 shared_prefix 与 dispersed_prefix 两组负载；
通过原生 /generate 接口发送 input_ids，使用流式响应；
统一设置 temperature=0、max_new_tokens=16、ignore_eos=true、sampling_seed=2026；
最大并发数为 8，每组 32 条测量请求；
采集成功率、吞吐量、缓存命中率、实际 Prefill token 数，以及 TTFT、TPOT、E2E 的 p50 / p95；
输出逐请求结果与汇总结果。

## 6.结果目录与报告表格的对应关系
 - report.pdf 中任务一的对照表对应：
results/target1/summary_combined.json

 - shared_prefix 组的逐请求结果对应：
results/target1/shared_prefix/per_request.jsonl
results/target1/shared_prefix/summary.json

 - dispersed_prefix 组的逐请求结果对应：
results/target1/dispersed_prefix/per_request.jsonl
results/target1/dispersed_prefix/summary.json

 - 两组使用的输入负载对应：
results/target1/loads/shared_prefix.json
results/target1/loads/dispersed_prefix.json